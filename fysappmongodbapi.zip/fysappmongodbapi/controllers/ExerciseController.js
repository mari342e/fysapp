const express = require("express");
const router = express.Router();
const bodyParser = require("body-parser");
const Exercise = require(__dirname +"/../Models/Exercise");
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

// CREATES A NEW exercise
//mangler at tilføje om den pågældende orderno i den gruppe er brugt

router.post("/", function(req, res) {
    Exercise.create(
    {
      name: req.body.name,
      createDate: req.body.createDate
    },
    function(err, exercise) {
      if (err)
        return res.status(500).send("There was a problem adding the information to the database.");

      res.status(200).send(exercise);
    }
    );
});
    
    // RETURNS ALL THE exerciseS IN THE DATABASE
router.get("/", function(req, res) {
    Exercise.find({}, function(err, exercises) {
    if (err)
      return res.status(500).send("There was a problem finding the exercises.");
    res.status(200).send(exercises);
    });
});

// GETS A SINGLE exercise FROM THE DATABASE
router.get("/:id", function(req, res) {
    Exercise.findOne(req.params.id, function(err, exercise) {
    if (err)
      return res.status(500).send("There was a problem finding the exercise.");
    if (!exercise) return res.status(404).send("No exercise found.");
    res.status(200).send(exercise);
    });
});
    
    // DELETES A exercise FROM THE DATABASE
router.delete("/:id", function(req, res) {
    Exercise.findByIdAndRemove(req.params.id, function(err, exercise) {
    if (err)
      return res.status(500).send("There was a problem deleting the exercise.");
    res.status(200).send("exercise " + exercise.name + " was deleted.");
    });
});
    
    // UPDATES A SINGLE exercise IN THE DATABASE
router.put("/:id", function (req, res) {
    Exercise.findOneAndUpdate(req.params.id, req.body, { new: true }, function (err, exercise) {
        if (err)
            return res.status(500).send("There was a problem updating the exercise. " + err.message);
        res.status(200).send(exercise);
    });
});
module.exports = router;