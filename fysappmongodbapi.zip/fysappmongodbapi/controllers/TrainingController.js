const express = require("express");
const router = express.Router();
const bodyParser = require("body-parser");
const Training = require(__dirname +"/../Models/Training");
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

// CREATES A NEW training
//mangler at tilføje om den pågældende orderno i den gruppe er brugt

router.post("/", function(req, res) {
    Training.create(
    {
      userID: req.body.userID,
      sessionID: req.body.sessionID,
      trainingFysioToday: req.body.trainingFysioToday,
      painsBefore: req.body.painsBefore,
      takenPainkillerBefore : req.body.takenPainkillerBefore, 
      typePainkillerBefore : req.body.typePainkillerBefore,   
      amountPainkillerBefore: req.body.amountPainkillerBefore,
      sideEffectsBefore: req.body.sideEffectsBefore,
      sideEffectsDescriptionBefore: req.body.sideEffectsDescriptionBefore,
      painsAfter: req.body.painsAfter,
      takenPainkillerAfter: req.body.takenPainkillerAfter,
      typePainkillerAfter: req.body.typePainkillerAfter,
      amountPainkillerAfter: req.body.amountPainkillerAfter,
      exhaustedAfter: req.body.exhaustedAfter,
      completed: req.body.completed,
      comments: req.body.comments,
      trainingExercises: req.body.trainingExercises,
      date: req.body.date
    },
    function(err, training) {
      if (err)
        return res.status(500).send("There was a problem adding the information to the database. create" + err);

      res.status(200).send(training);
    });
});
            // adds A SINGLE trainingExercise IN THE DATABASE
router.post("/addexercise/:id", function (req, res) {
  Training.findOneAndUpdate({_id : req.params.id},{$push: {trainingExercises: {
    exerciseID: req.body.exerciseID,
    time: req.body.time,
    set1Repetitions: req.body.set1Repetitions,
    set2Repetitions: req.body.set2Repetitions,
    set3Repetitions: req.body.set3Repetitions,
    set1Weights: req.body.set1Weights,
    set2Weights: req.body.set2Weights,
    set3Weights: req.body.set3Weights

}}}, function (err, training) {
      if (err)
          return res.status(500).send("There was a problem updating the training. " +err +" err.message: " + err.message); 
          
       Training.findOne({_id : req.params.id}, function(err, trainings) {
          if (err)
            return res.status(500).send("There was a problem finding the trainings after updating");
          res.status(200).send(trainings);
          });
      
  });
});
    // RETURNS ALL THE trainingS IN THE DATABASE
router.get("/", function(req, res) {
    Training.find({}, function(err, trainings) {
    if (err)
      return res.status(500).send("There was a problem finding the trainings.");
    res.status(200).send(trainings);
    });
});
// RETURNS ALL THE trainingS IN THE DATABASE with specific user and session id
router.get("/usersession/:id/:sessionid", function (req, res) {
  Training.find({userID : req.params.id, sessionID : req.params.sessionid}, function(err, trainings) {
      if (err)
        return res.status(500).send("There was a problem finding the trainings.");
      res.status(200).send(trainings);
      });
});
// RETURNS ALL THE trainingS IN THE DATABASE with specific user id
router.get("/user/:id", function (req, res) {
    Training.find({userID : req.params.id}, function(err, trainings) {
        if (err)
          return res.status(500).send("There was a problem finding the trainings.");
        res.status(200).send(trainings);
        });
});


// GETS A SINGLE training FROM THE DATABASE
router.get("/:id", function(req, res) {
    Training.findOne(req.params.id, function(err, training) {
    if (err)
      return res.status(500).send("There was a problem finding the training.");
    if (!training) return res.status(404).send("No training found.");
    res.status(200).send(training);
    });
});
    
    // DELETES A training FROM THE DATABASE
router.delete("/:id", function(req, res) {
    Training.findByIdAndRemove(req.params.id, function(err, training) {
    if (err)
      return res.status(500).send("There was a problem deleting the training.");
    res.status(200).send("training for groupID" + training.groupID + " was deleted.");
    });
});


    // UPDATES A SINGLE training IN THE DATABASE
router.put("/:id", function (req, res) {
    Training.findOneAndUpdate({'_id' : req.params.id}, req.body, { new: true }, function (err, training) {
        if (err)
            return res.status(500).send("There was a problem updating the training. " + err.message);
        res.status(200).send(training);
    });
});
module.exports = router;