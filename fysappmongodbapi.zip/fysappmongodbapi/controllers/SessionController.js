const express = require("express");
const router = express.Router();
const bodyParser = require("body-parser");
const Session = require(__dirname +"/../Models/Session");
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

// CREATES A NEW session
//mangler at tilføje om den pågældende orderno i den gruppe er brugt

router.post("/", function(req, res) {
    Session.create(
    {
      groupID: req.body.groupID,
      exerciseIDs: req.body.exerciseIDs,
      orderNo: req.body.orderNo,
      durationWeeks: req.body.durationWeeks,
      createDate: req.body.createDate
    },
    function(err, session) {
      if (err)
        return res.status(500).send("There was a problem adding the information to the database.");

      res.status(200).send(session);
    }
    );
});
    
    // RETURNS ALL THE sessionS IN THE DATABASE
router.get("/", function(req, res) {
    Session.find({}, function(err, sessions) {
    if (err)
      return res.status(500).send("There was a problem finding the sessions.");
    res.status(200).send(sessions);
    });
});
// RETURNS ALL THE sessionS IN THE DATABASE with specific group id
router.get("/group/:id", function (req, res) {
    Session.find({groupID : req.params.id}, function(err, sessions) {
        if (err)
          return res.status(500).send("There was a problem finding the sessions.");
        res.status(200).send(sessions);
        });
});
// GETS A SINGLE session FROM THE DATABASE
router.get("/:id", function(req, res) {
    Session.findOne(req.params.id, function(err, session) {
    if (err)
      return res.status(500).send("There was a problem finding the session.");
    if (!session) return res.status(404).send("No session found.");
    res.status(200).send(session);
    });
});
    
    // DELETES A session FROM THE DATABASE
router.delete("/:id", function(req, res) {
    Session.findByIdAndRemove(req.params.id, function(err, session) {
    if (err)
      return res.status(500).send("There was a problem deleting the session.");
    res.status(200).send("session for groupID" + session.groupID + " was deleted.");
    });
});
    
    // UPDATES A SINGLE session IN THE DATABASE
router.put("/:id", function (req, res) {
    Session.findOneAndUpdate({_id : req.params.id}, req.body, { new: true }, function (err, session) {
        if (err)
            return res.status(500).send("There was a problem updating the session. " + err.message);
        res.status(200).send(session);
    });
});
module.exports = router;