const mongoose = require("mongoose");
const options = { useNewUrlParser: true };
mongoose.set('useFindAndModify', false);
mongoose
.connect(
"mongodb+srv://Jesperlange1:5xCM.ekAAb4Vvn-@cluster0-lh9qc.mongodb.net/FysAppDB?retryWrites=true",
options
)
.then(() => {
console.log("MongoDB connected...");
})
.catch(err => console.log(err));