const express = require("express");
const db = require("./db");
const app = express();
const cors = require("cors");
const port = process.env.PORT || 3000;

const UserController = require("./controllers/UserController");
const SessionController = require("./controllers/SessionController");
const ExerciseController = require("./controllers/ExerciseController");
const TrainingController = require("./controllers/TrainingController");



app.use(cors());
app.use("/users", UserController);
app.use("/sessions", SessionController);
app.use("/exercises", ExerciseController);
app.use("/trainings", TrainingController);

app.listen(port, () => console.log(`Example app listening on port ${port}!`));