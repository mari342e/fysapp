const mongoose = require("mongoose");

const SessionSchema = new mongoose.Schema({
groupID: { type: Number, required: true },
exerciseIDs: { type: [String], required: true},
orderNo: { type: Number, required: true },
durationWeeks: { type: Number, required: true },
createDate: { type: Date, default: Date.now }
});
const Session = mongoose.model("Session", SessionSchema);

module.exports = Session;