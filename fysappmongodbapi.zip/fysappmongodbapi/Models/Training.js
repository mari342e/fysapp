const mongoose = require("mongoose");

const TrainingExerciseSchema = new mongoose.Schema({
    exerciseID: { type: String, required: true},
    time: { type: Date, required: true },
    set1Repetitions: { type: Number, required: true },
    set2Repetitions: { type: Number, required: false },
    set3Repetitions: { type: Number, required: false },
    set1Weights: { type: Number, required: true },
    set2Weights: { type: Number, required: false },
    set3Weights: { type: Number, required: false }   
});


const TrainingSchema = new mongoose.Schema({   
    userID: { type: String, required: true },
    sessionID: { type: String, required: true},
    trainingFysioToday: { type: Boolean, required: false },
    painsBefore: { type: Number, required: false },
    takenPainkillerBefore: { type: Boolean, required: false },
    typePainkillerBefore: { type: String, required: false },
    amountPainkillerBefore: { type: String, required: false },
    sideEffectsBefore: { type: Boolean, required: false },
    sideEffectsDescriptionBefore: { type: String, required: false },
    painsAfter: { type: Number, required: false },
    takenPainkillerAfter: { type: Boolean, required: false },
    typePainkillerAfter: { type: String, required: false },
    amountPainkillerAfter: { type: String, required: false },
    exhaustedAfter: { type: Boolean, required: false },
    comments:{ type: String, required: false },
    completed: {type:Boolean, default:false},
    trainingExercises:{ type: [TrainingExerciseSchema], required: false },
    date: { type: Date, default: Date.now }
});
const Training = mongoose.model("Training", TrainingSchema);

module.exports = Training;